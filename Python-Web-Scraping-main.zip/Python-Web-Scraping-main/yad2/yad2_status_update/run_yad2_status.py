from scrapy.cmdline import execute

execute("scrapy crawl yad2_updater".split())
