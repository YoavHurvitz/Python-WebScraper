from scrapy.cmdline import execute

execute("scrapy crawl yad2 -o yad2.json".split())
