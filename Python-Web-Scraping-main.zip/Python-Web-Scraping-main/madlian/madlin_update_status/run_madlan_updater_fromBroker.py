from scrapy.cmdline import execute

execute("scrapy crawl madlan_update_from_brocker".split())
