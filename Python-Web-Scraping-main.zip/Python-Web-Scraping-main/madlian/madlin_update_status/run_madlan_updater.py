from scrapy.cmdline import execute

execute("scrapy crawl madlan_updater".split())
